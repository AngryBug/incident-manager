const BASE_URL = "http://localhost:8080/auth";

export async function registerUser(user) {
  const res = await fetch(`${BASE_URL}/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
  if (!res.ok) throw new Error("Registration failed");
  return res.json();
}

export async function loginUser(credentials) {
  const res = await fetch(`${BASE_URL}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials),
  });
  if (!res.ok) throw new Error("Login failed");
  return res.text(); // JWT token as plain text
}

export async function createIncident(token, data) {
  const res = await fetch("http://localhost:8080/incidents/create", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to create incident");
  return res.json();
}

export async function getMyIncidents(token) {
  const res = await fetch("http://localhost:8080/incidents/my", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  if (!res.ok) throw new Error("Failed to fetch incidents");
  return res.json();
}

export async function searchIncident(token, incidentId) {
  const res = await fetch(
    `http://localhost:8080/incidents/search?incidentId=${incidentId}`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
  if (res.status === 404 || res.status === 400) return null;
  if (!res.ok) throw new Error("Search failed");
  return res.json();
}

export async function updateIncident(token, incidentId, data) {
  const res = await fetch(`http://localhost:8080/incidents/${incidentId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to update incident");
  return res.json();
}