import React from "react";
import "./TopBar.css";

export default function TopBar({ onLogout }) {
  const userName = localStorage.getItem("userName") || "User";

  return (
    <div className="topbar">
      <div className="topbar-content">
        <div className="topbar-left">
          <h1 className="app-title">Incident Manager</h1>
        </div>
        <div className="topbar-right">
          <span className="user-name">👤 {userName}</span>
          <button className="logout-btn" onClick={onLogout}>
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
