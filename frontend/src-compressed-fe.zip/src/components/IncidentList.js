import React, { useEffect, useState } from "react";
import { getMyIncidents, searchIncident } from "../api";
import "./IncidentList.css";

export default function IncidentList({ onCreateNew, onEdit }) {
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchId, setSearchId] = useState("");
  const [message, setMessage] = useState("");

  const token = localStorage.getItem("token");

  // Load user's incidents
  useEffect(() => {
    fetchMyIncidents();
  }, []);

  const fetchMyIncidents = async () => {
    try {
      setLoading(true);
      const data = await getMyIncidents(token);
      setIncidents(data);
      setMessage(data.length ? "" : "No incidents found.");
    } catch (err) {
      console.error(err);
      setMessage("❌ Failed to load incidents.");
    }
    setLoading(false);
  };

  const handleSearch = async () => {
    if (!searchId.trim()) return;
    setLoading(true);
    try {
      const result = await searchIncident(token, searchId.trim());
      setIncidents(result ? [result] : []);
      setMessage(result ? "" : "No incident found with that ID.");
    } catch (err) {
      console.error(err);
      //alert(err);
      setIncidents('');
      setMessage("Search failed.");
    }
    setLoading(false);
  };

  return (
    <div className="incident-list-page">
      <div className="incident-header"></div>

      <div className="incident-box">
        {/* Header Row */}
        <div className="incident-list-header">
          <h2>My Incidents</h2>
          <button className="new-btn" onClick={onCreateNew}>
            ➕ Create New
          </button>
        </div>

        {/* Search Row */}
        <div className="search-row">
          <input
            type="text"
            placeholder="Search by Incident ID"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
          />
          <button className="search-btn" onClick={handleSearch}>
            Search
          </button>
          <button className="reset-btn" onClick={fetchMyIncidents}>
            Reset
          </button>
        </div>

        {/* Incident Table */}
        {loading ? (
          <p style={{ textAlign: "center" }}>Loading...</p>
        ) : incidents.length > 0 ? (
          <div className="table-container">
            <table className="incident-table">
              <thead>
                <tr>
                  <th>Incident ID</th>
                  <th>Description</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Reported At</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {incidents.map((inc) => (
                  <tr key={inc.id}>
                    <td>{inc.incidentId}</td>
                    <td className="desc-cell">{inc.description}</td>
                    <td>{inc.priority}</td>
                    <td
                      className={
                        inc.status === "Closed"
                          ? "status-closed"
                          : inc.status === "In Progress"
                          ? "status-progress"
                          : "status-open"
                      }
                    >
                      {inc.status}
                    </td>
                    <td>
                      {new Date(inc.reportedAt).toLocaleString("en-IN", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}
                    </td>
                    <td>
                      {inc.status !== "Closed" ? (
                        <button
                          className="edit-btn"
                          onClick={() => onEdit(inc)}
                        >
                          Edit
                        </button>
                      ) : (
                        <span className="locked">Locked</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ textAlign: "center", marginTop: "20px" }}>{message}</p>
        )}
      </div>
    </div>
  );
}
