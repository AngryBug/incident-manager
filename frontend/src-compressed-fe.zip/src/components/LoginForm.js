import React, { useState } from "react";
import { loginUser } from "../api";
import "./LoginForm.css";

export default function LoginForm({ onLoginSuccess, onSwitchToRegister }) {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // ✅ Helper: Decode JWT token to extract user info
  function parseJwt(token) {
    try {
      const base64Url = token.split(".")[1];
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      return JSON.parse(window.atob(base64));
    } catch (e) {
      return null;
    }
  }

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const token = await loginUser(credentials);
      localStorage.setItem("token", token);

      // ✅ Decode and store user's name
      const decoded = parseJwt(token);
      const userEmail = decoded?.sub || decoded?.email || "User";
      const userName = userEmail.split("@")[0];
      localStorage.setItem("userName", userName);

      setMessage("✅ Login successful!");
      if (onLoginSuccess) onLoginSuccess();
    } catch {
      setMessage("❌ Invalid email or password");
    }

    setLoading(false);
  };

  return (
    <div className="login-page">
      <div className="login-header"></div>

      <div className="login-box">
        <h2>USER LOGIN</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={credentials.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={credentials.password}
            onChange={handleChange}
            required
          />

          <div className="forgot-link">
            <a href="#">Forgot password?</a>
          </div>

          <button type="submit" disabled={loading}>
            {loading ? "Logging in..." : "LOG ME IN"}
          </button>

          {/* 🔹 Register link below button */}
          <div className="register-link">
            <span>Don’t have an account? </span>
            <button
              type="button"
              onClick={onSwitchToRegister}
              className="register-btn"
            >
              Register
            </button>
          </div>
        </form>

        {message && <p className="login-message">{message}</p>}
      </div>
    </div>
  );
}
