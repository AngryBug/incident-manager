import React, { useState } from "react";
import { registerUser } from "../api";
import "./RegistrationForm.css";

export default function RegistrationForm({ onSuccess }) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    country: "",
    state: "",
    city: "",
    pincode: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState({});
  const [autoMsg, setAutoMsg] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // ✅ Fetch City & State when Pincode changes
  const handlePincodeBlur = async () => {
    const { pincode, country } = formData;
    if (!pincode || !country) return;

    setAutoMsg("Fetching location...");
    try {
      let city = "";
      let state = "";

      if (country.toLowerCase() === "india" || country.toLowerCase() === "in") {
        const res = await fetch(`https://api.postalpincode.in/pincode/${pincode}`);
        const data = await res.json();
        if (data[0]?.Status === "Success") {
          city = data[0].PostOffice[0].District;
          state = data[0].PostOffice[0].State;
          setAutoMsg("✅ Location auto-filled from pincode");
        } else {
          setAutoMsg("⚠️ No data found for this pincode. Please fill manually.");
        }
      } else {
        const res = await fetch(`https://api.zippopotam.us/${country.slice(0, 2).toLowerCase()}/${pincode}`);
        if (res.ok) {
          const data = await res.json();
          city = data.places?.[0]["place name"] || "";
          state = data.places?.[0]["state"] || "";
          setAutoMsg("✅ Location auto-filled from pincode");
        } else {
          setAutoMsg("⚠️ No data found for this pincode. Please fill manually.");
        }
      }

      if (city) setFormData((prev) => ({ ...prev, city }));
      if (state) setFormData((prev) => ({ ...prev, state }));
    } catch (err) {
      console.error("Pincode lookup failed:", err);
      setAutoMsg("⚠️ No data fetched. Please fill manually.");
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.firstName) newErrors.firstName = "First name is required";
    if (!formData.email) newErrors.email = "Email is required";
    if (!formData.address) newErrors.address = "Address is required";
    if (!formData.country) newErrors.country = "Country is required";
    if (!formData.state) newErrors.state = "State is required";
    if (!formData.city) newErrors.city = "City is required";
    if (!formData.pincode) newErrors.pincode = "Pincode is required";
    if (!formData.phone) newErrors.phone = "Mobile number is required";
    if (!formData.password) newErrors.password = "Password is required";
    if (formData.password !== formData.confirmPassword)
      newErrors.confirmPassword = "Passwords do not match";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    setMessage("");
    try {
      const payload = {
        username: `${formData.firstName} ${formData.lastName}`.trim(),
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        mobileNumber: formData.phone,
        address: formData.address,
        pincode: formData.pincode,
        city: formData.city,
        state: formData.state,
        country: formData.country,
        countryCode: formData.country.slice(0, 2).toUpperCase(),
        password: formData.password,
      };
      await registerUser(payload);
      setMessage("✅ Registered successfully! Please login.");
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        address: "",
        country: "",
        state: "",
        city: "",
        pincode: "",
        phone: "",
        password: "",
        confirmPassword: "",
        mobileNumber:""
      });
      setErrors({});
      if (onSuccess) onSuccess();
    } catch (err) {
      setMessage("❌ Registration failed. Please check inputs.");
    }
    setLoading(false);
  };

  return (
    <div className="register-page">
      <div className="register-header"></div>

      <div className="register-box">
        <h2>Create Account</h2>
        <form onSubmit={handleSubmit} className="register-form">
          {/* First and Last Name */}
          <div className="form-row">
            <div className="form-group">
              <label>First Name</label>
              <input
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                className={errors.firstName ? "error" : ""}
              />
              {errors.firstName && <span className="error-text">{errors.firstName}</span>}
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* Email */}
          <div className="form-group full">
            <label>Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? "error" : ""}
            />
            {errors.email && <span className="error-text">{errors.email}</span>}
          </div>

          {/* Address */}
          <div className="form-group full">
            <label>Address</label>
            <input
              name="address"
              value={formData.address}
              onChange={handleChange}
              className={errors.address ? "error" : ""}
            />
            {errors.address && <span className="error-text">{errors.address}</span>}
          </div>

          {/* Country & State */}
          <div className="form-row">
            <div className="form-group">
              <label>Country</label>
              <select
                name="country"
                value={formData.country}
                onChange={handleChange}
                className={errors.country ? "error" : ""}
              >
                <option value="">Select Country</option>
                <option value="India">India</option>
                <option value="USA">USA</option>
                <option value="UK">UK</option>
              </select>
              {errors.country && <span className="error-text">{errors.country}</span>}
            </div>

            <div className="form-group">
              <label>State</label>
              <input
                name="state"
                value={formData.state}
                onChange={handleChange}
                className={errors.state ? "error" : ""}
              />
              {errors.state && <span className="error-text">{errors.state}</span>}
            </div>
          </div>

          {/* City & Pincode */}
          <div className="form-row">
            <div className="form-group">
              <label>City</label>
              <input
                name="city"
                value={formData.city}
                onChange={handleChange}
                className={errors.city ? "error" : ""}
              />
              {errors.city && <span className="error-text">{errors.city}</span>}
            </div>
            <div className="form-group">
              <label>Pincode</label>
              <input
                name="pincode"
                value={formData.pincode}
                onChange={handleChange}
                onBlur={handlePincodeBlur}
                className={errors.pincode ? "error" : ""}
              />
              {errors.pincode && <span className="error-text">{errors.pincode}</span>}
            </div>
          </div>

          {autoMsg && <p className="auto-msg">{autoMsg}</p>}

          {/* Phone */}
          <div className="form-group full">
            <label>Mobile Number</label>
            <input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className={errors.phone ? "error" : ""}
            />
            {errors.phone && <span className="error-text">{errors.phone}</span>}
          </div>

          {/* Password + Confirm */}
          <div className="form-row">
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className={errors.password ? "error" : ""}
              />
              {errors.password && <span className="error-text">{errors.password}</span>}
            </div>
            <div className="form-group">
              <label>Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                className={errors.confirmPassword ? "error" : ""}
              />
              {errors.confirmPassword && (
                <span className="error-text">{errors.confirmPassword}</span>
              )}
            </div>
          </div>

          <button type="submit" disabled={loading}>
            {loading ? "Registering..." : "SIGN UP"}
          </button>
        </form>
        {message && <p className="register-message">{message}</p>}
      </div>
    </div>
  );
}
