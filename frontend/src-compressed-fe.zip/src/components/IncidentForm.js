import React, { useState, useEffect } from "react";
import { createIncident, updateIncident } from "../api";
import "./IncidentForm.css";

export default function IncidentForm({ onBackToList, editIncident }) {
  const isEdit = !!editIncident;

  const [incident, setIncident] = useState({
    type: "",
    description: "",
    priority: "",
    status: "Open",
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isEdit) {
      setIncident({
        type: editIncident.type,
        description: editIncident.description,
        priority: editIncident.priority,
        status: editIncident.status,
      });
    }
  }, [editIncident]);

  const handleChange = (e) => {
    setIncident({ ...incident, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!incident.type || !incident.description || !incident.priority) {
      setMessage("⚠️ Please fill all required fields.");
      return;
    }

    setLoading(true);
    setMessage("");
    const token = localStorage.getItem("token");

    try {
      if (isEdit) {
        await updateIncident(token, editIncident.incidentId, incident);
        setMessage("✅ Incident updated successfully!");
      } else {
        await createIncident(token, incident);
        setMessage("✅ Incident created successfully!");
        setIncident({ type: "", description: "", priority: "", status: "Open" });
      }
    } catch (err) {
      setMessage("❌ Failed to save incident.");
    }

    setLoading(false);
  };

  return (
    <div className="incident-page">
      <div className="incident-header"></div>

      <div className="incident-box">
        <h2>{isEdit ? "Edit Incident" : "Create New Incident"}</h2>
        <form onSubmit={handleSubmit} className="incident-form">
          <div className="form-group">
            <label>Type *</label>
            <select
              name="type"
              value={incident.type}
              onChange={handleChange}
              disabled={isEdit}
            >
              <option value="">Select Type</option>
              <option value="Enterprise">Enterprise</option>
              <option value="Government">Government</option>
            </select>
          </div>

          <div className="form-group">
            <label>Description *</label>
            <textarea
              name="description"
              value={incident.description}
              onChange={handleChange}
              rows="4"
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Priority *</label>
              <select
                name="priority"
                value={incident.priority}
                onChange={handleChange}
              >
                <option value="">Select Priority</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div className="form-group">
              <label>Status</label>
              <select
                name="status"
                value={incident.status}
                onChange={handleChange}
                disabled={editIncident?.status === "Closed"}
              >
                <option value="Open">Open</option>
                <option value="In Progress">In Progress</option>
                <option value="Closed">Closed</option>
              </select>
            </div>
          </div>

          <button type="submit" disabled={loading}>
            {loading
              ? isEdit
                ? "Updating..."
                : "Submitting..."
              : isEdit
              ? "UPDATE INCIDENT"
              : "SUBMIT INCIDENT"}
          </button>

          <button
            type="button"
            className="back-btn"
            onClick={onBackToList}
            style={{ marginTop: "10px" }}
          >
            ← Back to List
          </button>
        </form>
        {message && <p className="incident-message">{message}</p>}
      </div>
    </div>
  );
}
