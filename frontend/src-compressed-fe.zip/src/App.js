import React, { useState } from "react";
import LoginForm from "./components/LoginForm";
import RegistrationForm from "./components/RegistrationForm";
import IncidentForm from "./components/IncidentForm";
import IncidentList from "./components/IncidentList";
import TopBar from "./components/TopBar";

function App() {
  const [page, setPage] = useState("login");
  const [editIncident, setEditIncident] = useState(null);

  const handleLoginSuccess = () => setPage("list");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userName");
    setPage("login");
  };

  return (
    <div>
      {page === "login" && (
        <LoginForm
          onLoginSuccess={handleLoginSuccess}
          onSwitchToRegister={() => setPage("register")}
        />
      )}

      {page === "register" && (
        <RegistrationForm onSuccess={() => setPage("login")} />
      )}

      {page === "incident" && (
        <>
          <TopBar onLogout={handleLogout} />
          <IncidentForm
            onBackToList={() => {
              setEditIncident(null);
              setPage("list");
            }}
            editIncident={editIncident}
          />
        </>
      )}

      {page === "list" && (
        <>
          <TopBar onLogout={handleLogout} />
          <IncidentList
            onCreateNew={() => {
              setEditIncident(null);
              setPage("incident");
            }}
            onEdit={(incident) => {
              setEditIncident(incident);
              setPage("incident");
            }}
          />
        </>
      )}
    </div>
  );
}

export default App;
